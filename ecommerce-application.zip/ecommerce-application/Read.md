E-Commerce Application

Controllers:
 Product,Order,Category,Cart.
  

Product:-
1. /product/{name}
        
2. /product/
3. /product/categories/{name}
4. /product/productCategories
5./product/add