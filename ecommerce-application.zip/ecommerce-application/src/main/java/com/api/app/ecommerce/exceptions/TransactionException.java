package com.api.app.ecommerce.exceptions;

public class TransactionException extends IllegalArgumentException{
    public TransactionException(String message){super(message);}

}
