package com.api.app.ecommerce.enums;

public enum ResponseStatus
{
    success,
    error
}
