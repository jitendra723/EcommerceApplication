package com.api.app.ecommerce.service;

import com.api.app.ecommerce.dto.product.ProductDto;
import com.api.app.ecommerce.exceptions.OrderNotFoundException;
import com.api.app.ecommerce.exceptions.ProductNotExistException;
import com.api.app.ecommerce.model.Category;
import com.api.app.ecommerce.model.Product;
import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.repository.CategoryRepository;
import com.api.app.ecommerce.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Predicate;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final CategoryRepository categoryrepository;


    @Autowired
    public ProductService(final ProductRepository productRepository, final CategoryRepository categoryrepository) {
        this.productRepository = productRepository;
        this.categoryrepository = categoryrepository;

    }

    public List<ProductDto> listProducts() {
        List<Product> products = productRepository.findAll();
        List<ProductDto> productDtos = new ArrayList<>();
        for(Product product : products) {
            ProductDto productDto = getDtoFromProduct(product);
            productDtos.add(productDto);
        }
        return productDtos;
    }

    /**
     * @param name
     * @return
     */
    public List<ProductDto> listProductsByCategoryName(final String name) {
        Category category = categoryrepository.findByCategoryName(name);
        if(Objects.isNull(category)){throw new OrderNotFoundException("CategoryNotFound");
        }
        List<Product> products = productRepository.findAllByCategory(category);
        List<ProductDto> productDtos = new ArrayList<>();
        for(Product product : products) {
            ProductDto productDto = getDtoFromProduct(product);
            productDtos.add(productDto);
        }
        return productDtos;
    }

    public static ProductDto getDtoFromProduct(Product product) {
       final ProductDto productDto = new ProductDto(product);
        return productDto;
    }

    public static Product getProductFromDto(ProductDto productDto, Category category,User user) {
       final Product product = new Product(productDto, category,user);
        return product;
    }

    /**
     * @param productDto
     * @param category
     * @param user
     */
    public void addProduct(ProductDto productDto, Category category, final User user) {
        List<Product> products=getProductByUser(user);
        Predicate<Product> productLine=product ->product.getName().equals(productDto.getName())
                &&product.getCategory().getId()==productDto.getCategoryId();
        final Optional<Product> existingProduct = products.stream().filter(productLine).findFirst();
        final Product product;
        if(existingProduct.isPresent()){
            product = existingProduct.get();
            product.setQuantity(product.getQuantity()+productDto.getQuantity());
        }else{
            product = getProductFromDto(productDto, category,user);
        }
        saveProduct(product);
    }

    public Product getProductById(Integer productId) throws ProductNotExistException {
        Optional<Product> optionalProduct = productRepository.findById(productId);
        if (!optionalProduct.isPresent())
            throw new ProductNotExistException("Product id is invalid " + productId);
        return optionalProduct.get();
    }

    /**
     * @param categoryName
     * @param startRange
     * @param endRange
     * @return
     */
    public List<ProductDto> listProductsByCategoryNameAndPriceRange(String categoryName, Double startRange, Double endRange) {
        Category category = categoryrepository.findByCategoryName(categoryName);
        if(Objects.isNull(category)){throw new OrderNotFoundException("CategoryNotFound");}
        List<Product> products = productRepository.findAllByCategoryAndPriceBetween(category,startRange, endRange);
        List<ProductDto> productDtos = new ArrayList<>();
        for(Product product : products) {
            ProductDto productDto = getDtoFromProduct(product);
            productDtos.add(productDto);
        }
        return productDtos;
    }

    /**
     * @param productName
     * @return
     */
    public List<ProductDto> getProductDetails(final String productName) {
        List<Product> products= productRepository.findByNameIgnoreCaseContaining(productName);
        List<ProductDto> productDtos = new ArrayList<>();
        for(Product product : products) {
            ProductDto productDto = getDtoFromProduct(product);
            productDtos.add(productDto);
        }
        return productDtos;
    }

    public List<Product>getProductByUser(final User user){
      return productRepository.findByUser(user);
    }

    public void saveProduct(final Product product){
        productRepository.save(product);
    }
}
