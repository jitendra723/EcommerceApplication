package com.api.app.ecommerce.paymentfactory;

import com.api.app.ecommerce.model.User;
import org.springframework.stereotype.Component;

@Component
public interface Payment {
    String paymentSelector(final String paymentMode);
    void pay(final Double amount, final User user);
}
