package com.api.app.ecommerce.model;

import javax.persistence.*;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="address")
public class Address {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String city;
    @NotNull
    private Integer Phone;
    @NotNull
    private String AddressLine1;
    private String AddressLine2;
    private String State;
    @NotNull
    private String PostalCode;
    @ManyToOne
    @JoinColumn(name = "user_id", referencedColumnName = "id")
    private User user;

    public Address(){}
    public Address(final Integer id, final String city, final Integer phone, final String addressLine1, final String addressLine2, final String state, final String postalCode, final User user) {
        this.id = id;
        this.city = city;
        Phone = phone;
        AddressLine1 = addressLine1;
        AddressLine2 = addressLine2;
        State = state;
        PostalCode = postalCode;
        this.user = user;
    }
}
