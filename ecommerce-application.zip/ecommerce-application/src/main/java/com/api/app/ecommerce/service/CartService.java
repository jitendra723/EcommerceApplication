package com.api.app.ecommerce.service;

import com.api.app.ecommerce.dto.cart.AddToCartDto;
import com.api.app.ecommerce.dto.cart.CartDto;
import com.api.app.ecommerce.dto.cart.CartItemDto;
import com.api.app.ecommerce.exceptions.CartItemNotExistException;
import com.api.app.ecommerce.exceptions.ValidationException;
import com.api.app.ecommerce.model.Cart;
import com.api.app.ecommerce.model.Product;
import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.repository.CartRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Transactional
public class CartService {
    private final Logger log= LoggerFactory.getLogger(CartService.class);
    private final CartRepository cartRepository;

    @Autowired
    public CartService(final CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }


    public void addToCart(AddToCartDto addToCartDto, Product product, User user){
        validateProductAvailability(product,addToCartDto.getQuantity());
        Cart cart = new Cart(product, addToCartDto.getQuantity(), user);
        cartRepository.save(cart);
    }

    /**
     * @param product
     * @param quantity
     */
    private void validateProductAvailability(final Product product, final Integer quantity) {
        if (product.getQuantity() < quantity) {
            log.error("Seller does not have sufficient quantity to process order");
            throw new ValidationException("Seller does not have sufficient quantity to process order, available quantities=" + " " + product.getQuantity() + " for productId=" + " " + product.getId());
        }
    }

    /**
     * @param user
     * @return
     */
    public CartDto listCartItems(final User user) {
        final List<Cart> cartList = cartRepository.findAllByUserOrderByCreatedDateDesc(user);
        final  List<CartItemDto> cartItems = new ArrayList<>();
        for (Cart cart:cartList){
            CartItemDto cartItemDto = getDtoFromCart(cart);
            cartItems.add(cartItemDto);
        }
        double totalCost = 0;
        for (CartItemDto cartItemDto :cartItems){
            totalCost += (cartItemDto.getProduct().getPrice()* cartItemDto.getQuantity());
        }
        CartDto cartDto = new CartDto(cartItems,totalCost);
        return cartDto;
    }


    public static CartItemDto getDtoFromCart(final Cart cart) {
        final CartItemDto cartItemDto = new CartItemDto(cart);
        return cartItemDto;
    }

    /**
     * @param cartDto
     * @param user
     * @param product
     */
    public void updateCartItem(final AddToCartDto cartDto,
                               final User user,
                               final Product product){
        log.info("Update cart started--");
        Cart cart = cartRepository.getOne(cartDto.getId());
        cart.setQuantity(cartDto.getQuantity());
        cart.setCreatedDate(new Date());
        cartRepository.save(cart);
        log.info("Update cart completed");
    }

    public void deleteCartItem(final int id,final int userId) throws CartItemNotExistException {
        log.info("Cart deletion started--");
        if (!cartRepository.existsById(id))
            throw new CartItemNotExistException("Cart id is invalid : " + id);
        cartRepository.deleteById(id);
        log.info("Cart deletion completed");

    }

    public void deleteCartItems(final int userId) {
        cartRepository.deleteAll();
    }


    public void deleteUserCartItems(final User user) {
        cartRepository.deleteByUser(user);
    }
}


