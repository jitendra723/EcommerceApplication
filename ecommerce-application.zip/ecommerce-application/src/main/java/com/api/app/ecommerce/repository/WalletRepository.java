package com.api.app.ecommerce.repository;

import com.api.app.ecommerce.model.DigitalWallet;
import com.api.app.ecommerce.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface WalletRepository  extends JpaRepository<DigitalWallet,Integer> {
    Optional<DigitalWallet> findByUser(User user);
}
