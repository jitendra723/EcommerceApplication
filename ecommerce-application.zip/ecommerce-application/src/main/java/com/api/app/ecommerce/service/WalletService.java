package com.api.app.ecommerce.service;

import com.api.app.ecommerce.model.DigitalWallet;
import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.repository.WalletRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Optional;

@Service
@Transactional
public class WalletService {
    private final WalletRepository walletRepository;

    @Autowired
    public WalletService(final WalletRepository walletRepository) {
        this.walletRepository = walletRepository;
    }

    public void updateWallet(final DigitalWallet digitalWallet){
        walletRepository.save(digitalWallet);
    }

    public Optional<DigitalWallet> getUserWallet(final User user){
        return walletRepository.findByUser(user);
    }
}
