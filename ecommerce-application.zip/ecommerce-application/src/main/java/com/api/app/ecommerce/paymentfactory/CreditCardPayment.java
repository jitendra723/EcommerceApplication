package com.api.app.ecommerce.paymentfactory;

import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.enums.PaymentMode;
import org.springframework.stereotype.Component;

@Component
public class CreditCardPayment  implements Payment{
    @Override
    public String paymentSelector(String paymentMode) {
      return String.valueOf(PaymentMode.CREDIT_CARD);
    }

    /**
     * @param amount
     * @param user
     */
    @Override
    public void pay(Double amount, User user) {

    }
}
