package com.api.app.ecommerce.controller;

import com.api.app.ecommerce.common.Response;
import com.api.app.ecommerce.dto.order.ReturnOrderDto;
import com.api.app.ecommerce.exceptions.OrderNotFoundException;
import com.api.app.ecommerce.exceptions.ProductNotExistException;
import com.api.app.ecommerce.model.Order;
import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.service.OrderService;
import com.api.app.ecommerce.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotNull;
import java.util.HashMap;
import java.util.List;

@RestController
@RequestMapping("/order")
public class OrderController {
    private final Logger log= LoggerFactory.getLogger(OrderController.class);

    private final OrderService orderService;
    private final UserService userService;

    @Autowired
    public OrderController(final OrderService orderService, final UserService userService) {
        this.orderService = orderService;
        this.userService = userService;

    }


    /**
     * User can please order from here
     * @param email
     * @param paymentMode
     * @param sessionId
     * @return
     * @throws ProductNotExistException
     */
    @PostMapping("/add")
    public ResponseEntity<Response> placeOrder(@RequestHeader("email") String email, @RequestHeader("paymentMode") String paymentMode, @RequestParam("sessionId") String sessionId)
            throws ProductNotExistException {
        final User user = userService.findUserByEmail(email);
        orderService.placeOrder(user, sessionId,paymentMode);
        return new ResponseEntity<Response>(new Response(true, "Order has been placed"), HttpStatus.CREATED);
    }

    /**
     *  User can return order
     * @param email
     * @param sessionId
     * @param orderId
     * @param returnOrderDto
     * @return
     * @throws ProductNotExistException
     */
    @PostMapping("/{orderId}/return")
    public ResponseEntity<Response> returnOrder(@RequestHeader("email") @NotNull String email,
                                                @RequestParam("sessionId") String sessionId,
                                                @PathVariable("orderId")  @NotNull Integer orderId,
                                                @RequestBody ReturnOrderDto returnOrderDto) throws ProductNotExistException {
        final User user = userService.findUserByEmail(email);
        orderService.returnOrder(user,orderId, sessionId,returnOrderDto);
        return new ResponseEntity<Response>(new Response(true, "Order has been returned"), HttpStatus.CREATED);
    }

    /**
     *Show all orders by users
     * @param email
     * @return
     */
    @GetMapping("/")
    public ResponseEntity<List<Order>> getAllOrders(@RequestHeader("email") String email) {
        final User user = userService.findUserByEmail(email);
        List<Order> orderDtoList = orderService.listOrders(user);
        return new ResponseEntity<List<Order>>(orderDtoList,HttpStatus.OK);
    }

    /**
     * Return details for particular order
     * @param id
     * @return
     */
    @GetMapping("/{id}")
    public ResponseEntity<Object> getAllOrders(@PathVariable("id") Integer id)  {
        try {
            Order order = orderService.getOrder(id);
            return new ResponseEntity<>(order,HttpStatus.OK);
        }
        catch (OrderNotFoundException e) {
            return new ResponseEntity<>(e.getMessage(),HttpStatus.NOT_FOUND);
        }

    }

}
