package com.api.app.ecommerce.controller;

import java.util.List;
import java.util.Objects;

import javax.validation.Valid;

import com.api.app.ecommerce.common.Response;
import com.api.app.ecommerce.model.Category;
import com.api.app.ecommerce.service.CategoryService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/category")

public class CategoryController {

	private final Logger log= LoggerFactory.getLogger(CategoryController.class);

	private final CategoryService categoryService;

	@Autowired
	public CategoryController(final CategoryService categoryService) {
		this.categoryService = categoryService;
	}

	@GetMapping("/")
    public ResponseEntity<List<Category>> getCategories() {
        List<Category> body = categoryService.listCategories();
        return new ResponseEntity<List<Category>>(body, HttpStatus.OK);
    }

	/**
	 * @param category
	 * @return
	 */
	@PostMapping("/create")
	public ResponseEntity<Response> createCategory(@Valid @RequestBody Category category) {
		log.info("category creation started");
		if (Objects.nonNull(categoryService.readCategory(category.getCategoryName()))) {
			return new ResponseEntity<Response>(new Response(false, "category already exists"), HttpStatus.CONFLICT);
		}
		categoryService.createCategory(category);
		log.info("category creation completed");
		return new ResponseEntity<Response>(new Response(true, "created the category"), HttpStatus.CREATED);
	}

}
