package com.api.app.ecommerce.enums;

public enum PaymentMode {
    WALLET,CREDIT_CARD,DEBIT_CARD
}
