package com.api.app.ecommerce.controller;

import com.api.app.ecommerce.common.Response;
import com.api.app.ecommerce.dto.product.ProductDto;
import com.api.app.ecommerce.enums.Role;
import com.api.app.ecommerce.exceptions.CustomException;
import com.api.app.ecommerce.model.Category;
import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.service.CategoryService;
import com.api.app.ecommerce.service.ProductService;
import com.api.app.ecommerce.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/product")
public class ProductController {
    Logger log= LoggerFactory.getLogger(ProductController.class);
    private final ProductService productService;
    private final CategoryService categoryService;
    private final UserService userService;

    @Autowired
    public ProductController(final ProductService productService, final CategoryService categoryService, final UserService userService) {
        this.productService = productService;
        this.categoryService = categoryService;
        this.userService = userService;
    }

    /**
     * it returns all the products in all categories.
     * @return
     */
    @GetMapping("/")
    public ResponseEntity<List<ProductDto>> getProducts() {
        List<ProductDto> body = productService.listProducts();
        return new ResponseEntity<List<ProductDto>>(body, HttpStatus.OK);
    }

    /**
     * Returns all the Products for given search name.
     * @param productName
     * @return
     */
    @GetMapping("/{name}")
    public ResponseEntity<List<ProductDto>> getProductDetails(@PathVariable("name") final String productName) {
        List<ProductDto> body = productService.getProductDetails(productName);
        return new ResponseEntity<List<ProductDto>>(body, HttpStatus.OK);
    }

    /**
     * Search all products in particular category in multiple price range
     * @param categoryName
     * @param startRange
     * @param endRange
     * @return
     */
    @GetMapping("/categories/{name}")
    public ResponseEntity<List<ProductDto>> getProductRange(@PathVariable("name") final String categoryName,
                                                            @RequestParam Double startRange, @RequestParam Double endRange) {
        List<ProductDto> body = productService.listProductsByCategoryNameAndPriceRange(categoryName,startRange,endRange);
        return new ResponseEntity<List<ProductDto>>(body, HttpStatus.OK);
    }

    /**
     * Returns all categories
     * @return
     */
    @GetMapping("/productCategories")
    public ResponseEntity<List<Category>> getCategories() {
        List<Category> body = categoryService.listCategories();
        return new ResponseEntity<List<Category>>(body, HttpStatus.OK);
    }

    /**
     * Search product by category name
     * @param categoryName
     * @return
     */
    @GetMapping("/categories/category/{name}")
    public ResponseEntity<List<ProductDto>> getProductsByCategory(@PathVariable("name") final String categoryName) {
        List<ProductDto> body = productService.listProductsByCategoryName(categoryName);
        return new ResponseEntity<List<ProductDto>>(body, HttpStatus.OK);
    }

    /**
     * Seller can add product.
     * @param email
     * @param productDto
     * @return
     */
    @PostMapping("/add")
    public ResponseEntity<Response> addProduct(@RequestHeader("email") String email, @RequestBody ProductDto productDto) {
        log.info("add product started---");
        final User user = userService.findUserByEmail(email);
        validateSeller(user);
        Optional<Category> optionalCategory = categoryService.readCategory(productDto.getCategoryId());
        if (!optionalCategory.isPresent()) {
            return new ResponseEntity<Response>(new Response(false, "category is invalid"), HttpStatus.CONFLICT);
        }
        Category category = optionalCategory.get();
        productService.addProduct(productDto, category,user);
        log.info("product added successfully");
        return new ResponseEntity<Response>(new Response(true, "Product has been added"), HttpStatus.CREATED);
    }

    private void validateSeller(final User user) {
        if(!Role.seller.equals(user.getRole())){
            throw new CustomException("only seller allowed to add product");
        }
    }
}
