package com.api.app.ecommerce.service;

import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.paymentfactory.Payment;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class PaymentService {

    private final List<Payment> payments;

    @Autowired
    public PaymentService(List<Payment> payments) {
        this.payments = payments;
    }

    /**
     * @param totalCost
     * @param paymentMode
     * @param user
     */
    public void pay(final double totalCost, final String paymentMode,final User user) {
        Optional<Payment> paymentOption = payments.stream().filter((var) -> var.paymentSelector(paymentMode).equalsIgnoreCase(paymentMode)).findFirst();
        if(!paymentOption.isPresent()){throw new IllegalArgumentException("Please select valid payment option");}
        paymentOption.get().pay(totalCost, user);
    }
}
