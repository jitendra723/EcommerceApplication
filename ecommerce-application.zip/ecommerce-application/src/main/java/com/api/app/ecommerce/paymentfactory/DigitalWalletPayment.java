package com.api.app.ecommerce.paymentfactory;

import com.api.app.ecommerce.enums.PaymentMode;
import com.api.app.ecommerce.exceptions.TransactionException;
import com.api.app.ecommerce.model.DigitalWallet;
import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.service.WalletService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.transaction.Transactional;
import java.util.Optional;

@Component
@Transactional
public class DigitalWalletPayment implements Payment{
    private static final Logger LOGGER= LoggerFactory.getLogger(DigitalWalletPayment.class);

    private final WalletService walletService;

    @Autowired
    public DigitalWalletPayment(final WalletService walletService) {
        this.walletService = walletService;
    }


    @Override
    public String paymentSelector(final String paymentMode) {
        return String.valueOf(PaymentMode.WALLET);
    }

    /**
     * @param amount
     * @param user
     */
    @Override
    public void pay(final Double amount, final User user) {
        LOGGER.info("Payment started");
        final Optional<DigitalWallet> digitalWallet = walletService.getUserWallet(user);
        if(!digitalWallet.isPresent()){throw new TransactionException("No wallet found for User");}
        final DigitalWallet wallet = digitalWallet.get();
        if(wallet.getAmount()<amount){
            throw new TransactionException("No sufficient balance for this purchase, please recharge your wallet");
        }
        wallet.setAmount(wallet.getAmount()-amount);
        walletService.updateWallet(wallet);
        LOGGER.info("Payment completed");
    }
}
