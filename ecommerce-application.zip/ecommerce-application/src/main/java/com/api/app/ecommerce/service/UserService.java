package com.api.app.ecommerce.service;

import com.api.app.ecommerce.exceptions.CustomException;
import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Objects;


@Service
public class UserService {
    Logger logger = LoggerFactory.getLogger(UserService.class);

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public User findUserByEmail(final String email){
        User user = userRepository.findByEmail(email);
        if(Objects.isNull(user)){throw new CustomException("User not found");}
        return user;

    }

}
