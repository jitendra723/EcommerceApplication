package com.api.app.ecommerce.repository;

import com.api.app.ecommerce.model.Category;
import com.api.app.ecommerce.model.Product;
import com.api.app.ecommerce.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ProductRepository extends JpaRepository<Product, Integer> {
    List<Product> findAllByCategory(Category category);
    List<Product>findByName(String name);
    List<Product> findAllByCategoryAndPriceBetween(Category category,double  start, double end);
    List<Product> findByNameIgnoreCaseContaining(String name);
    List<Product> findByUser(User user);


}
