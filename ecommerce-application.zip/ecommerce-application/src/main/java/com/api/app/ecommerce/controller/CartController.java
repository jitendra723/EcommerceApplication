package com.api.app.ecommerce.controller;

import com.api.app.ecommerce.common.Response;
import com.api.app.ecommerce.dto.cart.AddToCartDto;
import com.api.app.ecommerce.dto.cart.CartDto;
import com.api.app.ecommerce.exceptions.CartItemNotExistException;
import com.api.app.ecommerce.model.Product;
import com.api.app.ecommerce.model.User;
import com.api.app.ecommerce.service.ProductService;
import com.api.app.ecommerce.service.CartService;
import com.api.app.ecommerce.service.UserService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/cart")
public class CartController {
    private final Logger log= LoggerFactory.getLogger(CartController.class);
    private final CartService cartService;
    private final ProductService productService;
    private final UserService userService;

    @Autowired
    public CartController(final CartService cartService, final ProductService productService, final UserService userService) {
        this.cartService = cartService;
        this.productService = productService;
        this.userService = userService;
    }

    /**
     * @param email
     * @param addToCartDto
     * @return
     */
    @PostMapping("/add")
    public ResponseEntity<Response> addToCart(@RequestHeader("email") String email, @RequestBody AddToCartDto addToCartDto){
        log.info("adding item to Cart started calling addToCart()");
        final User user = userService.findUserByEmail(email);
        Product product = productService.getProductById(addToCartDto.getProductId());
        cartService.addToCart(addToCartDto, product, user);
        log.info("Items added to cart successfully");
        return new ResponseEntity<Response>(new Response(true, "Added to cart"), HttpStatus.CREATED);

    }

    /**
     * It returns all the products in cart.
     * @param email
     * @return
     */
    @GetMapping("/showCart")
    public ResponseEntity<CartDto> getCartItems(@RequestHeader("email") String email) {
        final User user = userService.findUserByEmail(email);
        CartDto cartDto = cartService.listCartItems(user);
        return new ResponseEntity<CartDto>(cartDto,HttpStatus.OK);
    }

    /**
     * @param email
     * @param cartDto
     * @return
     */
    @PutMapping("/update/{cartItemId}")
    public ResponseEntity<Response> updateCartItem(@RequestHeader("email") String email, @RequestBody @Valid AddToCartDto cartDto) {
        final User user = userService.findUserByEmail(email);
        Product product = productService.getProductById(cartDto.getProductId());
        cartService.updateCartItem(cartDto, user,product);
        return new ResponseEntity<Response>(new Response(true, "Product has been updated"), HttpStatus.OK);
    }

    /**
     * @param email
     * @param itemID
     * @return
     * @throws CartItemNotExistException
     */
    @DeleteMapping("/delete/{cartItemId}")
    public ResponseEntity<Response> deleteCartItem(@RequestHeader("email") String email, @PathVariable("cartItemId") int itemID) throws CartItemNotExistException {
        final User user = userService.findUserByEmail(email);
        cartService.deleteCartItem(itemID, user.getId());
        return new ResponseEntity<Response>(new Response(true, "Item has been removed"), HttpStatus.OK);
    }

}
