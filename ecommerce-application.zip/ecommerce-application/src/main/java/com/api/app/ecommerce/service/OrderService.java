package com.api.app.ecommerce.service;

import com.api.app.ecommerce.dto.cart.CartDto;
import com.api.app.ecommerce.dto.cart.CartItemDto;
import com.api.app.ecommerce.dto.order.PlaceOrderDto;
import com.api.app.ecommerce.dto.order.ReturnOrderDto;
import com.api.app.ecommerce.exceptions.OrderNotFoundException;
import com.api.app.ecommerce.exceptions.ValidationException;
import com.api.app.ecommerce.model.*;
import com.api.app.ecommerce.repository.OrderRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;
import java.util.function.Predicate;


@Service
@Transactional
public class OrderService {

    private final Logger log= LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository orderRepository;
    private final CartService cartService;
    private final PaymentService paymentService;
    private final  OrderItemsService orderItemsService;
    private final ProductService productService;
    private final WalletService walletService;

    public OrderService(final OrderRepository orderRepository,
                        final CartService cartService,
                        final PaymentService paymentService,
                        final OrderItemsService orderItemsService,
                        final ProductService productService,
                        final WalletService walletService) {
        this.orderRepository = orderRepository;
        this.cartService = cartService;
        this.paymentService = paymentService;
        this.orderItemsService = orderItemsService;
        this.productService = productService;
        this.walletService = walletService;
    }


    public Order saveOrder(PlaceOrderDto orderDto, User user, String sessionID){
        Order order = getOrderFromDto(orderDto, user, sessionID);
        return orderRepository.save(order);
    }

    private Order getOrderFromDto(PlaceOrderDto orderDto, User user, String sessionID) {
        return new Order(orderDto, user,sessionID);

    }

    public List<Order> listOrders(User user) {
        List<Order> orderList = orderRepository.findAllByUserOrderByCreatedDateDesc(user);
        return orderList;
    }

    public Order getOrder(int orderId) throws OrderNotFoundException {
        Optional<Order> order = orderRepository.findById(orderId);
        if (order.isPresent()) {
            return order.get();
        }
        throw new OrderNotFoundException("Order not found");
    }

    /**
     *  method validate cart.
     *  After successful payment, order will be placed and Order items will be updated
     * @param user
     * @param sessionId
     * @param paymentMode
     */

    public void placeOrder(final User user, final String sessionId,final String paymentMode) {
        log.info("Order processing started..");
        CartDto cartDto = cartService.listCartItems(user);
        validateCart(cartDto);
        PlaceOrderDto placeOrderDto = new PlaceOrderDto();
        placeOrderDto.setUser(user);
        placeOrderDto.setTotalPrice(cartDto.getTotalCost());

        Order newOrder = saveOrder(placeOrderDto, user, sessionId);
        List<CartItemDto> cartItemDtoList = cartDto.getcartItems();
        cartItemDtoList.forEach(this::checkAvailableProductQuantity);
        log.info("payment started for order");
        paymentService.pay(cartDto.getTotalCost(),paymentMode,user);
        log.info("payment completed for order");

        for (CartItemDto cartItemDto : cartItemDtoList) {
            OrderItem orderItem = new OrderItem(
                    newOrder,
                    cartItemDto.getProduct(),
                    cartItemDto.getQuantity(),
                    cartItemDto.getProduct().getPrice());
            orderItemsService.addOrderedProducts(orderItem);
            updateProduct(cartItemDto);

        }
        cartService.deleteUserCartItems(user);
        log.info("Order processing completed");
    }

    private void validateCart(final CartDto cartDto) {
        if(cartDto.getcartItems().stream().count()==0){throw new ValidationException("Order can not be process as cart is empty");}
    }

    /**
     * @param cartItemDto
     */
    private void updateProduct(final CartItemDto cartItemDto) {
        final Product product = cartItemDto.getProduct();
        product.setQuantity(product.getQuantity()-cartItemDto.getQuantity());
        productService.saveProduct(product);
    }

    private void checkAvailableProductQuantity(final CartItemDto cartItemDto) {
        if(cartItemDto.getQuantity()>cartItemDto.getProduct().getQuantity()){
            throw new ValidationException("Seller does not have sufficient quantity to process order, Available quantities"+ " "+cartItemDto.getProduct().getQuantity() + " for productId "+" "+ cartItemDto.getId());}
    }

    /**
     *
     * @param user
     * @param orderId
     * @param sessionId
     * @param returnOrderDto
     */
    public void returnOrder(User user, Integer orderId, String sessionId, ReturnOrderDto returnOrderDto) {
        log.info("Refund order started");
        final Order order = getOrder(orderId);
        Double productPrice = getProductPrice(order, returnOrderDto);
        final OrderItem orderItem = order.getOrderItems().stream().filter(x -> x.getProduct().getId() == returnOrderDto.getProductId()).findFirst().get();
        int quantity = orderItem.getQuantity();
        order.setTotalPrice(order.getTotalPrice()-productPrice);
        orderItem.setQuantity(quantity-returnOrderDto.getQuantity());
        orderRepository.save(order);
        refundAmount(user, returnOrderDto, productPrice, orderItem);
        log.info("Refund processed completed");

    }


    private void refundAmount(final User user, final ReturnOrderDto returnOrderDto, final Double productPrice, final OrderItem orderItem) {
        Optional<DigitalWallet> userWallet = walletService.getUserWallet(user);
        DigitalWallet digitalWallet = userWallet.get();
        double amount = digitalWallet.getAmount();
        digitalWallet.setAmount(amount+ productPrice);
        log.info("Amount refund started");
        walletService.updateWallet(digitalWallet);
        log.info("Amount refund completed");
        orderItem.getProduct().setQuantity(orderItem.getProduct().getQuantity()+ returnOrderDto.getQuantity());
    }

    private Double getProductPrice(final Order order, final ReturnOrderDto returnOrderDto) {
        Predicate<OrderItem>orderMatch=orderItem -> returnOrderDto.getQuantity()<=orderItem.getQuantity() && orderItem.getProduct().getId() == returnOrderDto.getProductId();
        boolean returnOrderMatch=  order.getOrderItems().stream().anyMatch(orderMatch);
        if(!returnOrderMatch){ throw new IllegalArgumentException("return item mismatch");}
        return order.getOrderItems().stream().filter(orderMatch).map(x -> x.getProduct().getPrice()).findFirst().get()*returnOrderDto.getQuantity();

    }

}


