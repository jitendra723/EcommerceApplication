package com.api.app.ecommerce.enums;

public enum Role {
    user,
    seller,
    admin
}
