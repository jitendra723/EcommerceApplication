INSERT INTO USERS(EMAIL ,FIRST_NAME ,LAST_NAME ,ROLE ) values ('test3@gmail.com','jitendra','kumatr','user'),('test2@gmail.com','test','kumatr','seller'),('test1@gmail.com','jitendra','kumatr','user'),('test4@gmail.com','test','name','seller');

INSERT INTO CATEGORIES (CATEGORY_NAME ,DESCRIPTION ) VALUES('Books', 'all Bookes'),('Fashion', 'fashion store'),('Men', 'fashion store for men'),('BabyProduct', 'fashion store for Baby'),('Women', 'fashion store for Women');

INSERT INTO PRODUCTS (DESCRIPTION ,NAME ,PRICE ,CATEGORY_ID,USER_ID ,QUANTITY) VALUES('spritual books','Holiday',300.20,1,2,10),('new world','sky',10.20,2,2,300);

INSERT INTO WALLET (AMOUNT ,CREATED_DATE ,USER_ID ) VALUES(1000.00,'2012-09-17 18:47:52.69',1);